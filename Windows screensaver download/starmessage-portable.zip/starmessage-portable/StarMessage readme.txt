These are the files of the StarMessage screensaver.


If you do not want or cannot use the automatic screensaver setup, you can follow these instructions to manually install the screensaver on your Windows computer.


Overview of the tasks:

For 64bit versions of Windows, all the files must be copied to the "SysWOW64" folder.
For 32bit versions of Windows, all the files must be copied to the "System32" folder.
StarMessage must be selected as the default screensaver.

Step by step instructions:

1. Unzip the StarMessage-portable.zip to your desktop.

2. Open the "Run" window by pressing on your keyboard the Windows Logo key and the [R] key at the same time.

3. In the "Open:" field, 
for 64 bit Windows type: %SystemRoot%\SysWOW64\ 
for 32 bit Windows type: %SystemRoot%\System32\
and press Ok.
 
4. This will open the Windows explorer at the destination folder.

5. Copy the files from inside the unzipped StarMessage-portable.zip into the destination folder (SysWOW64 or System32).

6. Go back to the unzipped folder. Right-click on the StarMessage.scr file (the one with the black sky icon) and in the pop-up menu, select "Install".

7. This will open the control panel where you can select StarMessage as the default screensaver and set the idle time to start the screensaver, for example in 5 minutes.
